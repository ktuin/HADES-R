# HADES_2.0
HADES one master event version with quaternion rotations and NN module.


PREREQUISITES
-------------

Please download and install the `latlon2cart` module from: https://github.com/wulwife/latlon2cart or `pip install latlon2cart`.


**Dependencies:**

- `scipy`  > version 1.9.3
- `math`, `halo`, `numpy`, `matplotlib`, `pandas`, `datetime`, `time`

**To install all:**

`conda install math halo numpy matplotlib pandas datetime time`

